import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Optional, Dict, List, Any
import ast

class VisualizationManager:
    def __init__(self):
        self.color_palette = px.colors.qualitative.Set3
        self.default_template = "plotly_white"
    
    def create_bar_chart(self, data: pd.DataFrame, x: str, y: str, title: str, 
                        orientation: str = 'v', color: Optional[str] = None):
        """Create a customized bar chart"""
        if orientation == 'h':
            fig = px.bar(data, x=x, y=y, orientation='h', title=title, color=color,
                        template=self.default_template)
        else:
            fig = px.bar(data, x=x, y=y, title=title, color=color,
                        template=self.default_template)
        
        fig.update_layout(
            title_font_size=16,
            showlegend=True if color else False
        )
        return fig
    
    def create_line_chart(self, data: pd.DataFrame, x: str, y: str, title: str,
                         color: Optional[str] = None):
        """Create a customized line chart"""
        fig = px.line(data, x=x, y=y, title=title, color=color,
                     template=self.default_template, markers=True)
        
        fig.update_layout(
            title_font_size=16,
            hovermode='x unified'
        )
        return fig
    
    def create_scatter_plot(self, data: pd.DataFrame, x: str, y: str, title: str,
                           size: Optional[str] = None, color: Optional[str] = None,
                           trendline: Optional[str] = None):
        """Create a customized scatter plot"""
        fig = px.scatter(data, x=x, y=y, title=title, size=size, color=color,
                        trendline=trendline, template=self.default_template)
        
        fig.update_layout(
            title_font_size=16
        )
        return fig
    
    def create_pie_chart(self, data: pd.DataFrame, values: str, names: str, title: str):
        """Create a customized pie chart"""
        fig = px.pie(data, values=values, names=names, title=title,
                    template=self.default_template)
        
        fig.update_layout(
            title_font_size=16
        )
        return fig
    
    def create_heatmap(self, data: pd.DataFrame, title: str):
        """Create a correlation heatmap"""
        fig = px.imshow(data, title=title, template=self.default_template,
                       aspect="auto")
        
        fig.update_layout(
            title_font_size=16
        )
        return fig
    
    def analyze_developer_ratings(self, games_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze average ratings by developer"""
        # Parse team information and calculate average ratings
        developer_ratings = []
        
        for _, row in games_df.iterrows():
            if pd.notna(row['Team']) and pd.notna(row['Rating']):
                try:
                    # Try to parse as list first
                    teams = ast.literal_eval(row['Team'])
                    if isinstance(teams, list):
                        for team in teams:
                            developer_ratings.append({
                                'Team': str(team).strip("'\""),
                                'Rating': row['Rating']
                            })
                    else:
                        developer_ratings.append({
                            'Team': str(teams).strip("'\""),
                            'Rating': row['Rating']
                        })
                except:
                    # If parsing fails, treat as string
                    team_str = str(row['Team']).strip("[]'\"")
                    if ',' in team_str:
                        teams = [t.strip() for t in team_str.split(',')]
                        for team in teams:
                            developer_ratings.append({
                                'Team': team.strip("'\""),
                                'Rating': row['Rating']
                            })
                    else:
                        developer_ratings.append({
                            'Team': team_str,
                            'Rating': row['Rating']
                        })
        
        if developer_ratings:
            ratings_df = pd.DataFrame(developer_ratings)
            avg_ratings = ratings_df.groupby('Team').agg({
                'Rating': ['mean', 'count']
            }).reset_index()
            
            avg_ratings.columns = ['Team', 'avg_rating', 'game_count']
            avg_ratings = avg_ratings[avg_ratings['game_count'] >= 2]  # At least 2 games
            avg_ratings = avg_ratings.sort_values('avg_rating', ascending=False)
            
            return avg_ratings
        
        return pd.DataFrame()
    
    def analyze_genre_distribution(self, games_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze genre distribution"""
        all_genres = []
        
        for genres_str in games_df['Genres'].dropna():
            try:
                # Try to parse as list
                genres_list = ast.literal_eval(genres_str)
                if isinstance(genres_list, list):
                    all_genres.extend([g.strip("'\"") for g in genres_list])
                else:
                    all_genres.append(str(genres_list).strip("'\""))
            except:
                # If parsing fails, split by comma
                if ',' in str(genres_str):
                    genres_list = [g.strip() for g in str(genres_str).split(',')]
                    all_genres.extend([g.strip("'\"[]") for g in genres_list])
                else:
                    all_genres.append(str(genres_str).strip("'\"[]"))
        
        if all_genres:
            genre_counts = pd.Series(all_genres).value_counts().reset_index()
            genre_counts.columns = ['genre', 'count']
            return genre_counts
        
        return pd.DataFrame()
    
    def analyze_release_trends(self, games_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze game release trends over years"""
        if 'Release_Year' in games_df.columns:
            yearly_releases = games_df['Release_Year'].value_counts().sort_index()
            yearly_releases = yearly_releases[yearly_releases.index >= 1980]  # Filter reasonable years
            
            trend_df = pd.DataFrame({
                'year': yearly_releases.index,
                'count': yearly_releases.values
            })
            return trend_df
        
        return pd.DataFrame()
    
    def analyze_plays_by_genre(self, games_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze average plays by genre"""
        genre_plays = []
        
        for _, row in games_df.iterrows():
            if pd.notna(row['Genres']) and pd.notna(row['Plays']):
                try:
                    # Parse genres
                    genres_list = ast.literal_eval(row['Genres'])
                    if isinstance(genres_list, list):
                        for genre in genres_list:
                            genre_plays.append({
                                'genre': str(genre).strip("'\""),
                                'plays': row['Plays']
                            })
                    else:
                        genre_plays.append({
                            'genre': str(genres_list).strip("'\""),
                            'plays': row['Plays']
                        })
                except:
                    # Handle string format
                    genres_str = str(row['Genres']).strip("[]'\"")
                    if ',' in genres_str:
                        genres_list = [g.strip() for g in genres_str.split(',')]
                        for genre in genres_list:
                            genre_plays.append({
                                'genre': genre.strip("'\""),
                                'plays': row['Plays']
                            })
                    else:
                        genre_plays.append({
                            'genre': genres_str,
                            'plays': row['Plays']
                        })
        
        if genre_plays:
            plays_df = pd.DataFrame(genre_plays)
            avg_plays = plays_df.groupby('genre')['plays'].mean().sort_values(ascending=False).reset_index()
            avg_plays.columns = ['genre', 'avg_plays']
            return avg_plays
        
        return pd.DataFrame()
    
    def analyze_developer_productivity(self, games_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze developer productivity by game count"""
        developer_counts = []
        
        for _, row in games_df.iterrows():
            if pd.notna(row['Team']):
                try:
                    # Try to parse as list
                    teams = ast.literal_eval(row['Team'])
                    if isinstance(teams, list):
                        for team in teams:
                            developer_counts.append(str(team).strip("'\""))
                    else:
                        developer_counts.append(str(teams).strip("'\""))
                except:
                    # Handle string format
                    team_str = str(row['Team']).strip("[]'\"")
                    if ',' in team_str:
                        teams = [t.strip() for t in team_str.split(',')]
                        developer_counts.extend([t.strip("'\"") for t in teams])
                    else:
                        developer_counts.append(team_str)
        
        if developer_counts:
            productivity = pd.Series(developer_counts).value_counts().reset_index()
            productivity.columns = ['Team', 'game_count']
            return productivity.sort_values('game_count', ascending=False)
        
        return pd.DataFrame()
    
    def create_regional_heatmap(self, sales_df: pd.DataFrame, by_genre: bool = True):
        """Create regional sales heatmap"""
        if by_genre:
            # Group by genre and sum regional sales
            regional_data = sales_df.groupby('Genre')[
                ['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']
            ].sum()
            
            # Convert to percentage for better visualization
            regional_pct = regional_data.div(regional_data.sum(axis=1), axis=0)
            
            fig = px.imshow(
                regional_pct.T,
                labels=dict(x="Genre", y="Region", color="Sales Share"),
                title="Regional Sales Distribution by Genre",
                template=self.default_template
            )
        else:
            # Platform-based heatmap
            regional_data = sales_df.groupby('Platform')[
                ['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']
            ].sum().head(15)  # Top 15 platforms
            
            regional_pct = regional_data.div(regional_data.sum(axis=1), axis=0)
            
            fig = px.imshow(
                regional_pct.T,
                labels=dict(x="Platform", y="Region", color="Sales Share"),
                title="Regional Sales Distribution by Platform (Top 15)",
                template=self.default_template
            )
        
        fig.update_layout(title_font_size=16)
        return fig
    
    def create_dual_axis_chart(self, data: pd.DataFrame, x_col: str, y1_col: str, y2_col: str,
                              title: str, y1_title: str, y2_title: str):
        """Create a chart with dual y-axes"""
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        
        # Add first trace
        fig.add_trace(
            go.Scatter(x=data[x_col], y=data[y1_col], mode='lines+markers', name=y1_title),
            secondary_y=False
        )
        
        # Add second trace
        fig.add_trace(
            go.Scatter(x=data[x_col], y=data[y2_col], mode='lines+markers', name=y2_title),
            secondary_y=True
        )
        
        # Update axes titles
        fig.update_xaxes(title_text=x_col)
        fig.update_yaxes(title_text=y1_title, secondary_y=False)
        fig.update_yaxes(title_text=y2_title, secondary_y=True)
        
        fig.update_layout(
            title_text=title,
            title_font_size=16,
            template=self.default_template
        )
        
        return fig
    
    def create_correlation_matrix(self, data: pd.DataFrame, columns: List[str], title: str):
        """Create correlation matrix visualization"""
        # Select numeric columns and calculate correlation
        numeric_data = data[columns].select_dtypes(include=[np.number])
        if len(numeric_data.columns) < 2:
            return None
        
        corr_matrix = numeric_data.corr()
        
        fig = px.imshow(
            corr_matrix,
            title=title,
            template=self.default_template,
            color_continuous_scale='RdBu',
            aspect="auto"
        )
        
        fig.update_layout(title_font_size=16)
        return fig
    
    def create_top_performers_chart(self, data: pd.DataFrame, metric_col: str, 
                                   name_col: str, title: str, top_n: int = 10):
        """Create top performers chart"""
        top_data = data.nlargest(top_n, metric_col)
        
        fig = px.bar(
            top_data, 
            x=metric_col, 
            y=name_col, 
            orientation='h',
            title=title,
            template=self.default_template
        )
        
        fig.update_layout(
            title_font_size=16,
            yaxis={'categoryorder': 'total ascending'}
        )
        
        return fig
    
    def create_trend_analysis(self, data: pd.DataFrame, x_col: str, y_col: str, 
                             group_col: str, title: str, top_groups: int = 8):
        """Create trend analysis for multiple groups"""
        # Get top groups by total value
        top_group_names = data.groupby(group_col)[y_col].sum().nlargest(top_groups).index
        filtered_data = data[data[group_col].isin(top_group_names)]
        
        fig = px.line(
            filtered_data, 
            x=x_col, 
            y=y_col, 
            color=group_col,
            title=title,
            template=self.default_template,
            markers=True
        )
        
        fig.update_layout(
            title_font_size=16,
            hovermode='x unified'
        )
        
        return fig
    
    def create_bubble_chart(self, data: pd.DataFrame, x: str, y: str, size: str, 
                           color: str, title: str):
        """Create bubble chart"""
        fig = px.scatter(
            data, 
            x=x, 
            y=y, 
            size=size, 
            color=color,
            title=title,
            template=self.default_template,
            hover_data=[color]
        )
        
        fig.update_layout(title_font_size=16)
        return fig
    
    def create_distribution_plot(self, data: pd.DataFrame, column: str, title: str,
                                bins: int = 30):
        """Create distribution plot"""
        fig = px.histogram(
            data, 
            x=column, 
            nbins=bins,
            title=title,
            template=self.default_template
        )
        
        fig.update_layout(
            title_font_size=16,
            showlegend=False
        )
        
        return fig
    
    def create_box_plot(self, data: pd.DataFrame, x: str, y: str, title: str):
        """Create box plot for distribution analysis"""
        fig = px.box(
            data, 
            x=x, 
            y=y, 
            title=title,
            template=self.default_template
        )
        
        fig.update_layout(title_font_size=16)
        return fig
