import pandas as pd
import numpy as np
import re
from datetime import datetime
import ast

class DataProcessor:
    def __init__(self):
        pass
    
    def clean_games_data(self, games_df):
        """Clean and preprocess the games dataset"""
        df = games_df.copy()
        
        # Remove the unnamed index column if it exists
        if 'Unnamed: 0' in df.columns:
            df = df.drop('Unnamed: 0', axis=1)
        
        # Clean Title column
        df['Title'] = df['Title'].astype(str).str.strip()
        
        # Process Release Date
        df['Release Date'] = pd.to_datetime(df['Release Date'], errors='coerce')
        df['Release_Year'] = df['Release Date'].dt.year
        
        # Clean and process Team column
        df['Team'] = df['Team'].apply(self._parse_team_list)
        
        # Clean Rating column
        df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')
        
        # Clean numeric columns
        numeric_columns = ['Times Listed', 'Number of Reviews', 'Plays', 'Playing', 'Backlogs', 'Wishlist']
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Process Genres column
        df['Genres'] = df['Genres'].apply(self._parse_genres_list)
        df['Primary_Genre'] = df['Genres'].apply(self._get_primary_genre)
        
        # Create normalized title for matching
        df['Title_Normalized'] = df['Title'].apply(self._normalize_title)
        
        # Remove rows with missing essential data
        df = df.dropna(subset=['Title'])
        
        return df
    
    def clean_sales_data(self, sales_df):
        """Clean and preprocess the sales dataset"""
        df = sales_df.copy()
        
        # Clean Name column
        df['Name'] = df['Name'].astype(str).str.strip()
        
        # Clean Year column
        df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
        
        # Clean Platform column
        df['Platform'] = df['Platform'].astype(str).str.strip()
        
        # Clean Genre column
        df['Genre'] = df['Genre'].astype(str).str.strip()
        
        # Clean Publisher column
        df['Publisher'] = df['Publisher'].astype(str).str.strip()
        
        # Clean sales columns
        sales_columns = ['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales']
        for col in sales_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Create normalized name for matching
        df['Name_Normalized'] = df['Name'].apply(self._normalize_title)
        
        # Remove rows with missing essential data
        df = df.dropna(subset=['Name', 'Global_Sales'])
        df = df[df['Global_Sales'] > 0]  # Remove games with zero sales
        
        return df
    
    def merge_datasets(self, games_df, sales_df):
        """Merge games and sales datasets"""
        # Try exact title matching first
        merged = pd.merge(
            games_df, 
            sales_df, 
            left_on='Title_Normalized', 
            right_on='Name_Normalized',
            how='inner'
        )
        
        # If we have few matches, try fuzzy matching
        if len(merged) < 100:
            merged_fuzzy = self._fuzzy_merge(games_df, sales_df)
            merged = pd.concat([merged, merged_fuzzy]).drop_duplicates()
        
        return merged
    
    def _parse_team_list(self, team_str):
        """Parse team/developer list from string representation"""
        if pd.isna(team_str) or team_str == 'nan':
            return None
        
        try:
            # Try to evaluate as Python list
            team_list = ast.literal_eval(team_str)
            if isinstance(team_list, list):
                return ', '.join([str(team).strip("'\"") for team in team_list])
            else:
                return str(team_list)
        except:
            # If that fails, return as string
            return str(team_str).strip("[]'\"")
    
    def _parse_genres_list(self, genres_str):
        """Parse genres list from string representation"""
        if pd.isna(genres_str) or genres_str == 'nan':
            return None
        
        try:
            # Try to evaluate as Python list
            genres_list = ast.literal_eval(genres_str)
            if isinstance(genres_list, list):
                return ', '.join([str(genre).strip("'\"") for genre in genres_list])
            else:
                return str(genres_list)
        except:
            # If that fails, return as string
            return str(genres_str).strip("[]'\"")
    
    def _get_primary_genre(self, genres_str):
        """Extract primary genre from genres string"""
        if pd.isna(genres_str):
            return None
        
        try:
            genres_list = ast.literal_eval(genres_str)
            if isinstance(genres_list, list) and len(genres_list) > 0:
                return genres_list[0].strip("'\"")
        except:
            pass
        
        # Fallback: return first genre from comma-separated string
        if ',' in str(genres_str):
            return str(genres_str).split(',')[0].strip()
        else:
            return str(genres_str).strip("[]'\"")
    
    def _normalize_title(self, title):
        """Normalize title for better matching"""
        if pd.isna(title):
            return ''
        
        # Convert to lowercase
        normalized = str(title).lower()
        
        # Remove special characters and extra spaces
        normalized = re.sub(r'[^\w\s]', '', normalized)
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        # Remove common words that might cause mismatches
        common_words = ['the', 'a', 'an', 'and', 'or', 'of', 'in', 'on', 'at', 'to', 'for']
        words = normalized.split()
        filtered_words = [word for word in words if word not in common_words]
        
        return ' '.join(filtered_words)
    
    def _fuzzy_merge(self, games_df, sales_df):
        """Perform fuzzy matching between datasets"""
        # This is a simplified fuzzy matching approach
        # In production, you might want to use libraries like fuzzywuzzy
        
        merged_list = []
        
        for _, game_row in games_df.iterrows():
            game_title_norm = game_row['Title_Normalized']
            
            # Find potential matches in sales data
            for _, sales_row in sales_df.iterrows():
                sales_title_norm = sales_row['Name_Normalized']
                
                # Simple similarity check
                if (game_title_norm in sales_title_norm or 
                    sales_title_norm in game_title_norm):
                    
                    # Combine the rows
                    combined_row = pd.concat([game_row, sales_row])
                    merged_list.append(combined_row)
        
        if merged_list:
            return pd.DataFrame(merged_list).drop_duplicates()
        else:
            return pd.DataFrame()
    
    def get_data_quality_report(self, df, dataset_name):
        """Generate data quality report for a dataset"""
        report = {
            'dataset': dataset_name,
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_data': {},
            'data_types': {},
            'duplicates': 0
        }
        
        # Missing data analysis
        for col in df.columns:
            missing_count = df[col].isna().sum()
            missing_pct = (missing_count / len(df)) * 100
            report['missing_data'][col] = {
                'count': missing_count,
                'percentage': round(missing_pct, 2)
            }
        
        # Data types
        for col in df.columns:
            report['data_types'][col] = str(df[col].dtype)
        
        # Duplicates
        if 'Title' in df.columns:
            report['duplicates'] = df['Title'].duplicated().sum()
        elif 'Name' in df.columns:
            report['duplicates'] = df['Name'].duplicated().sum()
        
        return report
    
    def create_genre_mapping(self, games_df, sales_df):
        """Create mapping between different genre representations"""
        games_genres = set()
        sales_genres = set()
        
        # Extract all genres from games dataset
        for genres_str in games_df['Genres'].dropna():
            try:
                genres_list = ast.literal_eval(genres_str)
                if isinstance(genres_list, list):
                    games_genres.update([g.strip("'\"") for g in genres_list])
            except:
                if ',' in str(genres_str):
                    games_genres.update([g.strip() for g in str(genres_str).split(',')])
                else:
                    games_genres.add(str(genres_str).strip("[]'\""))
        
        # Extract all genres from sales dataset
        sales_genres = set(sales_df['Genre'].dropna().unique())
        
        return {
            'games_genres': sorted(list(games_genres)),
            'sales_genres': sorted(list(sales_genres)),
            'common_genres': sorted(list(games_genres.intersection(sales_genres)))
        }
