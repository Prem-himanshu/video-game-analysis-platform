import sqlite3
import pandas as pd
import os
from typing import Optional, List, Dict, Any

class DatabaseManager:
    def __init__(self, db_path: str = "video_games.db"):
        self.db_path = db_path
        self.connection = None
    
    def connect(self):
        """Establish database connection"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            return True
        except sqlite3.Error as e:
            print(f"Database connection error: {e}")
            return False
    
    def disconnect(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
    
    def create_tables(self):
        """Create database tables for storing game data"""
        if not self.connect():
            return False
        
        try:
            cursor = self.connection.cursor()
            
            # Games table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS games (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    release_date DATE,
                    release_year INTEGER,
                    team TEXT,
                    rating REAL,
                    times_listed INTEGER,
                    number_of_reviews INTEGER,
                    genres TEXT,
                    primary_genre TEXT,
                    summary TEXT,
                    reviews TEXT,
                    plays INTEGER,
                    playing INTEGER,
                    backlogs INTEGER,
                    wishlist INTEGER,
                    title_normalized TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Sales table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rank_id INTEGER,
                    name TEXT NOT NULL,
                    platform TEXT,
                    year INTEGER,
                    genre TEXT,
                    publisher TEXT,
                    na_sales REAL,
                    eu_sales REAL,
                    jp_sales REAL,
                    other_sales REAL,
                    global_sales REAL,
                    name_normalized TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Merged data table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS merged_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_id INTEGER,
                    sales_id INTEGER,
                    title TEXT,
                    name TEXT,
                    rating REAL,
                    platform TEXT,
                    year INTEGER,
                    genre TEXT,
                    publisher TEXT,
                    global_sales REAL,
                    plays INTEGER,
                    wishlist INTEGER,
                    backlogs INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (game_id) REFERENCES games (id),
                    FOREIGN KEY (sales_id) REFERENCES sales (id)
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_games_title ON games(title)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_games_rating ON games(rating)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_games_genre ON games(primary_genre)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_name ON sales(name)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_platform ON sales(platform)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_genre ON sales(genre)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_global ON sales(global_sales)')
            
            self.connection.commit()
            return True
            
        except sqlite3.Error as e:
            print(f"Error creating tables: {e}")
            return False
        finally:
            self.disconnect()
    
    def insert_data(self, games_df: pd.DataFrame, sales_df: pd.DataFrame, merged_df: pd.DataFrame):
        """Insert processed data into database tables"""
        if not self.connect():
            return False
        
        try:
            # Clear existing data
            cursor = self.connection.cursor()
            cursor.execute('DELETE FROM merged_data')
            cursor.execute('DELETE FROM games')
            cursor.execute('DELETE FROM sales')
            
            # Insert games data
            games_data = []
            for _, row in games_df.iterrows():
                # Handle Release Date conversion
                release_date = row.get('Release Date')
                if release_date is not None and not pd.isna(release_date):
                    if hasattr(release_date, 'strftime'):
                        release_date = release_date.strftime('%Y-%m-%d')
                    else:
                        release_date = str(release_date)
                else:
                    release_date = None
                
                games_data.append((
                    row.get('Title', ''),
                    release_date,
                    row.get('Release_Year'),
                    row.get('Team'),
                    row.get('Rating'),
                    row.get('Times Listed'),
                    row.get('Number of Reviews'),
                    row.get('Genres'),
                    row.get('Primary_Genre'),
                    row.get('Summary', '')[:1000] if pd.notna(row.get('Summary')) else '',  # Truncate long summaries
                    row.get('Reviews', '')[:1000] if pd.notna(row.get('Reviews')) else '',   # Truncate long reviews
                    row.get('Plays'),
                    row.get('Playing'),
                    row.get('Backlogs'),
                    row.get('Wishlist'),
                    row.get('Title_Normalized', '')
                ))
            
            cursor.executemany('''
                INSERT INTO games (title, release_date, release_year, team, rating, times_listed, 
                                 number_of_reviews, genres, primary_genre, summary, reviews, plays, 
                                 playing, backlogs, wishlist, title_normalized)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', games_data)
            
            # Insert sales data
            sales_data = []
            for _, row in sales_df.iterrows():
                sales_data.append((
                    row.get('Rank'),
                    row.get('Name', ''),
                    row.get('Platform', ''),
                    row.get('Year'),
                    row.get('Genre', ''),
                    row.get('Publisher', ''),
                    row.get('NA_Sales'),
                    row.get('EU_Sales'),
                    row.get('JP_Sales'),
                    row.get('Other_Sales'),
                    row.get('Global_Sales'),
                    row.get('Name_Normalized', '')
                ))
            
            cursor.executemany('''
                INSERT INTO sales (rank_id, name, platform, year, genre, publisher, na_sales, 
                                 eu_sales, jp_sales, other_sales, global_sales, name_normalized)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', sales_data)
            
            # Insert merged data if available
            if not merged_df.empty:
                merged_data = []
                for _, row in merged_df.iterrows():
                    merged_data.append((
                        None,  # game_id - would need lookup
                        None,  # sales_id - would need lookup
                        row.get('Title', ''),
                        row.get('Name', ''),
                        row.get('Rating'),
                        row.get('Platform', ''),
                        row.get('Year'),
                        row.get('Genre', ''),
                        row.get('Publisher', ''),
                        row.get('Global_Sales'),
                        row.get('Plays'),
                        row.get('Wishlist'),
                        row.get('Backlogs')
                    ))
                
                cursor.executemany('''
                    INSERT INTO merged_data (game_id, sales_id, title, name, rating, platform, year, 
                                           genre, publisher, global_sales, plays, wishlist, backlogs)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', merged_data)
            
            self.connection.commit()
            return True
            
        except sqlite3.Error as e:
            print(f"Error inserting data: {e}")
            self.connection.rollback()
            return False
        except Exception as e:
            print(f"Unexpected error inserting data: {e}")
            return False
        finally:
            self.disconnect()
    
    def execute_query(self, query: str, params: Optional[tuple] = None) -> Optional[pd.DataFrame]:
        """Execute a SQL query and return results as DataFrame"""
        if not self.connect():
            return None
        
        try:
            if params:
                df = pd.read_sql_query(query, self.connection, params=params)
            else:
                df = pd.read_sql_query(query, self.connection)
            return df
        except Exception as e:
            print(f"Error executing query: {e}")
            return None
        finally:
            self.disconnect()
    
    def get_top_rated_games(self, limit: int = 10) -> Optional[pd.DataFrame]:
        """Get top-rated games from database"""
        query = '''
            SELECT title, rating, team, primary_genre, plays, wishlist
            FROM games 
            WHERE rating IS NOT NULL 
            ORDER BY rating DESC, number_of_reviews DESC 
            LIMIT ?
        '''
        return self.execute_query(query, (limit,))
    
    def get_sales_by_region(self) -> Optional[pd.DataFrame]:
        """Get total sales by region"""
        query = '''
            SELECT 
                SUM(na_sales) as north_america,
                SUM(eu_sales) as europe,
                SUM(jp_sales) as japan,
                SUM(other_sales) as other_regions,
                SUM(global_sales) as global_total
            FROM sales
        '''
        return self.execute_query(query)
    
    def get_platform_performance(self) -> Optional[pd.DataFrame]:
        """Get platform performance metrics"""
        query = '''
            SELECT 
                platform,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales,
                MAX(global_sales) as best_seller_sales
            FROM sales 
            WHERE platform IS NOT NULL
            GROUP BY platform
            ORDER BY total_sales DESC
        '''
        return self.execute_query(query)
    
    def get_genre_analysis(self) -> Optional[pd.DataFrame]:
        """Get genre performance analysis"""
        query = '''
            SELECT 
                genre,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales,
                MAX(global_sales) as best_seller_sales
            FROM sales 
            WHERE genre IS NOT NULL
            GROUP BY genre
            ORDER BY total_sales DESC
        '''
        return self.execute_query(query)
    
    def get_yearly_trends(self) -> Optional[pd.DataFrame]:
        """Get yearly gaming trends"""
        query = '''
            SELECT 
                year,
                COUNT(*) as releases,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales
            FROM sales 
            WHERE year IS NOT NULL AND year > 1980
            GROUP BY year
            ORDER BY year
        '''
        return self.execute_query(query)
    
    def get_publisher_rankings(self) -> Optional[pd.DataFrame]:
        """Get publisher performance rankings"""
        query = '''
            SELECT 
                publisher,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales,
                MAX(global_sales) as best_seller_sales
            FROM sales 
            WHERE publisher IS NOT NULL
            GROUP BY publisher
            HAVING game_count >= 3
            ORDER BY total_sales DESC
        '''
        return self.execute_query(query)
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        if not self.connect():
            return {}
        
        try:
            cursor = self.connection.cursor()
            
            stats = {}
            
            # Games table stats
            cursor.execute('SELECT COUNT(*) FROM games')
            stats['games_count'] = cursor.fetchone()[0]
            
            # Sales table stats
            cursor.execute('SELECT COUNT(*) FROM sales')
            stats['sales_count'] = cursor.fetchone()[0]
            
            # Merged data stats
            cursor.execute('SELECT COUNT(*) FROM merged_data')
            stats['merged_count'] = cursor.fetchone()[0]
            
            # Data quality stats
            cursor.execute('SELECT COUNT(*) FROM games WHERE rating IS NOT NULL')
            stats['games_with_ratings'] = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM sales WHERE global_sales > 0')
            stats['games_with_sales'] = cursor.fetchone()[0]
            
            return stats
            
        except sqlite3.Error as e:
            print(f"Error getting database stats: {e}")
            return {}
        finally:
            self.disconnect()
    
    def backup_database(self, backup_path: str) -> bool:
        """Create a backup of the database"""
        try:
            if os.path.exists(self.db_path):
                import shutil
                shutil.copy2(self.db_path, backup_path)
                return True
            return False
        except Exception as e:
            print(f"Error creating backup: {e}")
            return False
