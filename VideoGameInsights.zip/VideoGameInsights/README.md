# Video Game Sales & Engagement Analysis Platform

A comprehensive Streamlit-based analytics platform for video game sales and engagement data analysis. This project provides interactive visualizations and insights to answer 30+ business questions about gaming industry trends.

## Features

- **Data Processing**: Clean and merge video game sales and engagement datasets
- **Interactive Visualizations**: 30+ charts and dashboards covering key business metrics
- **SQL Database Integration**: Structured data storage with SQLite
- **Multiple Analysis Sections**:
  - Game Metadata Analysis
  - Sales Data Analysis
  - Regional Analysis
  - Genre & Platform Performance
  - Developer & Publisher Insights
  - Trend Analysis
  - KPI Dashboard

## Technologies Used

- **Python 3.11**
- **Streamlit** - Web application framework
- **Plotly** - Interactive visualizations
- **Pandas** - Data manipulation and analysis
- **SQLite** - Database management
- **NumPy** - Numerical computing

## Project Structure

```
├── app.py                 # Main Streamlit application
├── data_processor.py      # Data cleaning and processing
├── database.py           # Database management
├── visualizations.py     # Visualization components
├── attached_assets/      # Data files
│   ├── games.csv        # Game engagement data
│   └── vgsales.csv      # Video game sales data
├── .streamlit/
│   └── config.toml      # Streamlit configuration
└── requirements.txt     # Python dependencies
```

## Installation & Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd video-game-analysis
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
streamlit run app.py
```

4. Open your browser and navigate to `http://localhost:8501`

## Usage

1. **Load Data**: Click "Load & Process Data" in the sidebar
2. **Navigate Sections**: Use the dropdown menu to explore different analyses
3. **Interactive Charts**: Hover over charts for detailed information
4. **Export Insights**: Screenshots and data can be exported from visualizations

## Data Sources

- **games.csv**: Contains game metadata including ratings, genres, plays, wishlists
- **vgsales.csv**: Contains sales data by region, platform, and publisher

## Key Analysis Questions Answered

### Game Metadata (games.csv)
1. Top-rated games by user reviews
2. Developers with highest average ratings
3. Most common genres distribution
4. Games with highest backlog vs wishlist ratio
5. Game release trends over years
6. Distribution of user ratings
7. Most wishlisted games
8. Average plays per genre
9. Developer productivity analysis

### Sales Data (vgsales.csv)
10. Regional sales comparison
11. Best-selling platforms
12. Sales trends over years
13. Top publishers by sales
14. Global best-selling games
15. Regional sales by platform
16. Platform market evolution
17. Regional genre preferences
18. Yearly sales changes
19. Publisher performance metrics

### Merged Analysis
21. Genre performance vs sales
22. Rating correlation with sales
23. High-rated games by platform
24. Release and sales trends
25. Wishlist correlation with sales
26. Genre engagement vs sales gaps
27. User engagement patterns
28. Cross-platform genre analysis
29. Regional sales heatmaps
30. Performance optimization insights

## Database Schema

The application creates three main tables:
- **games**: Game metadata and engagement metrics
- **sales**: Sales data by region and platform
- **merged_data**: Combined insights from both datasets

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is for educational and analytical purposes.

## Skills Demonstrated

- **Python Programming**: Data processing, web development
- **Data Analysis**: EDA, statistical analysis, data cleaning
- **Data Visualization**: Interactive charts, dashboards
- **Database Management**: SQL queries, data modeling
- **Web Development**: Streamlit application development
- **Business Intelligence**: KPI tracking, trend analysis

## Contact

For questions or suggestions regarding this analytics platform, please open an issue in the repository.