import pandas as pd
import numpy as np
import os
from typing import Optional, List, Dict, Any
from sqlalchemy import create_engine, text, MetaData, Table, Column, Integer, String, Float, Date, Text, DateTime
from sqlalchemy.exc import SQLAlchemyError
import psycopg2
from datetime import datetime
import logging

class PostgreSQLManager:
    """
    Advanced PostgreSQL database manager for video game analytics
    """
    
    def __init__(self):
        self.database_url = os.getenv('DATABASE_URL')
        self.engine = None
        self.metadata = MetaData()
        self.setup_logging()
    
    def setup_logging(self):
        """Setup logging for database operations"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def connect(self):
        """Establish database connection using SQLAlchemy"""
        try:
            self.engine = create_engine(self.database_url)
            # Test connection
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            self.logger.info("Successfully connected to PostgreSQL database")
            return True
        except SQLAlchemyError as e:
            self.logger.error(f"Database connection error: {e}")
            return False
    
    def create_tables(self):
        """Create optimized database tables for video game analytics"""
        if not self.connect():
            return False
        
        try:
            with self.engine.connect() as conn:
                # Drop existing tables if they exist
                conn.execute(text("DROP TABLE IF EXISTS merged_analytics CASCADE"))
                conn.execute(text("DROP TABLE IF EXISTS sales_data CASCADE"))
                conn.execute(text("DROP TABLE IF EXISTS games_metadata CASCADE"))
                
                # Games metadata table
                conn.execute(text("""
                    CREATE TABLE games_metadata (
                        id SERIAL PRIMARY KEY,
                        title VARCHAR(500) NOT NULL,
                        release_date DATE,
                        release_year INTEGER,
                        team TEXT,
                        rating DECIMAL(3,2),
                        times_listed INTEGER,
                        number_of_reviews INTEGER,
                        genres TEXT,
                        primary_genre VARCHAR(100),
                        summary TEXT,
                        reviews TEXT,
                        plays INTEGER,
                        playing INTEGER,
                        backlogs INTEGER,
                        wishlist INTEGER,
                        title_normalized VARCHAR(500),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CONSTRAINT valid_rating CHECK (rating >= 0 AND rating <= 5)
                    )
                """))
                
                # Sales data table
                conn.execute(text("""
                    CREATE TABLE sales_data (
                        id SERIAL PRIMARY KEY,
                        rank_position INTEGER,
                        name VARCHAR(500) NOT NULL,
                        platform VARCHAR(50),
                        year INTEGER,
                        genre VARCHAR(100),
                        publisher VARCHAR(200),
                        na_sales DECIMAL(8,2),
                        eu_sales DECIMAL(8,2),
                        jp_sales DECIMAL(8,2),
                        other_sales DECIMAL(8,2),
                        global_sales DECIMAL(8,2),
                        name_normalized VARCHAR(500),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CONSTRAINT valid_year CHECK (year >= 1970 AND year <= 2030),
                        CONSTRAINT valid_sales CHECK (global_sales >= 0)
                    )
                """))
                
                # Merged analytics table
                conn.execute(text("""
                    CREATE TABLE merged_analytics (
                        id SERIAL PRIMARY KEY,
                        game_id INTEGER REFERENCES games_metadata(id),
                        sales_id INTEGER REFERENCES sales_data(id),
                        title VARCHAR(500),
                        name VARCHAR(500),
                        rating DECIMAL(3,2),
                        platform VARCHAR(50),
                        year INTEGER,
                        genre VARCHAR(100),
                        publisher VARCHAR(200),
                        global_sales DECIMAL(8,2),
                        plays INTEGER,
                        wishlist INTEGER,
                        backlogs INTEGER,
                        engagement_score DECIMAL(10,2),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                
                # Create indexes for better performance
                indexes = [
                    "CREATE INDEX idx_games_title ON games_metadata(title)",
                    "CREATE INDEX idx_games_rating ON games_metadata(rating)",
                    "CREATE INDEX idx_games_genre ON games_metadata(primary_genre)",
                    "CREATE INDEX idx_games_year ON games_metadata(release_year)",
                    "CREATE INDEX idx_sales_name ON sales_data(name)",
                    "CREATE INDEX idx_sales_platform ON sales_data(platform)",
                    "CREATE INDEX idx_sales_genre ON sales_data(genre)",
                    "CREATE INDEX idx_sales_global ON sales_data(global_sales)",
                    "CREATE INDEX idx_sales_year ON sales_data(year)",
                    "CREATE INDEX idx_merged_rating ON merged_analytics(rating)",
                    "CREATE INDEX idx_merged_sales ON merged_analytics(global_sales)"
                ]
                
                for index_sql in indexes:
                    conn.execute(text(index_sql))
                
                conn.commit()
                self.logger.info("Successfully created database tables and indexes")
                return True
                
        except SQLAlchemyError as e:
            self.logger.error(f"Error creating tables: {e}")
            return False
    
    def insert_data(self, games_df: pd.DataFrame, sales_df: pd.DataFrame, merged_df: pd.DataFrame):
        """Insert processed data into PostgreSQL tables"""
        if not self.connect():
            return False
        
        try:
            with self.engine.connect() as conn:
                # Clear existing data
                conn.execute(text("TRUNCATE TABLE merged_analytics, games_metadata, sales_data RESTART IDENTITY CASCADE"))
                
                # Prepare games data
                games_data = []
                for _, row in games_df.iterrows():
                    release_date = None
                    if row.get('Release Date') is not None and not pd.isna(row.get('Release Date')):
                        if hasattr(row.get('Release Date'), 'strftime'):
                            release_date = row.get('Release Date').strftime('%Y-%m-%d')
                        else:
                            release_date = str(row.get('Release Date'))
                    
                    games_data.append({
                        'title': str(row.get('Title', ''))[:500],
                        'release_date': release_date,
                        'release_year': int(row.get('Release_Year')) if pd.notna(row.get('Release_Year')) else None,
                        'team': str(row.get('Team', ''))[:1000] if pd.notna(row.get('Team')) else None,
                        'rating': float(row.get('Rating')) if pd.notna(row.get('Rating')) else None,
                        'times_listed': int(row.get('Times Listed')) if pd.notna(row.get('Times Listed')) else None,
                        'number_of_reviews': int(row.get('Number of Reviews')) if pd.notna(row.get('Number of Reviews')) else None,
                        'genres': str(row.get('Genres', ''))[:1000] if pd.notna(row.get('Genres')) else None,
                        'primary_genre': str(row.get('Primary_Genre', ''))[:100] if pd.notna(row.get('Primary_Genre')) else None,
                        'summary': str(row.get('Summary', ''))[:2000] if pd.notna(row.get('Summary')) else None,
                        'reviews': str(row.get('Reviews', ''))[:2000] if pd.notna(row.get('Reviews')) else None,
                        'plays': int(row.get('Plays')) if pd.notna(row.get('Plays')) else None,
                        'playing': int(row.get('Playing')) if pd.notna(row.get('Playing')) else None,
                        'backlogs': int(row.get('Backlogs')) if pd.notna(row.get('Backlogs')) else None,
                        'wishlist': int(row.get('Wishlist')) if pd.notna(row.get('Wishlist')) else None,
                        'title_normalized': str(row.get('Title_Normalized', ''))[:500]
                    })
                
                # Insert games data
                if games_data:
                    games_df_clean = pd.DataFrame(games_data)
                    games_df_clean.to_sql('games_metadata', conn, if_exists='append', index=False, method='multi')
                    self.logger.info(f"Inserted {len(games_data)} games records")
                
                # Prepare sales data
                sales_data = []
                for _, row in sales_df.iterrows():
                    sales_data.append({
                        'rank_position': int(row.get('Rank')) if pd.notna(row.get('Rank')) else None,
                        'name': str(row.get('Name', ''))[:500],
                        'platform': str(row.get('Platform', ''))[:50] if pd.notna(row.get('Platform')) else None,
                        'year': int(row.get('Year')) if pd.notna(row.get('Year')) else None,
                        'genre': str(row.get('Genre', ''))[:100] if pd.notna(row.get('Genre')) else None,
                        'publisher': str(row.get('Publisher', ''))[:200] if pd.notna(row.get('Publisher')) else None,
                        'na_sales': float(row.get('NA_Sales')) if pd.notna(row.get('NA_Sales')) else 0.0,
                        'eu_sales': float(row.get('EU_Sales')) if pd.notna(row.get('EU_Sales')) else 0.0,
                        'jp_sales': float(row.get('JP_Sales')) if pd.notna(row.get('JP_Sales')) else 0.0,
                        'other_sales': float(row.get('Other_Sales')) if pd.notna(row.get('Other_Sales')) else 0.0,
                        'global_sales': float(row.get('Global_Sales')) if pd.notna(row.get('Global_Sales')) else 0.0,
                        'name_normalized': str(row.get('Name_Normalized', ''))[:500]
                    })
                
                # Insert sales data
                if sales_data:
                    sales_df_clean = pd.DataFrame(sales_data)
                    sales_df_clean.to_sql('sales_data', conn, if_exists='append', index=False, method='multi')
                    self.logger.info(f"Inserted {len(sales_data)} sales records")
                
                # Insert merged data if available
                if not merged_df.empty:
                    merged_data = []
                    for _, row in merged_df.iterrows():
                        # Calculate engagement score
                        engagement_score = 0
                        if pd.notna(row.get('Plays')):
                            engagement_score += float(row.get('Plays', 0)) * 0.4
                        if pd.notna(row.get('Wishlist')):
                            engagement_score += float(row.get('Wishlist', 0)) * 0.3
                        if pd.notna(row.get('Backlogs')):
                            engagement_score += float(row.get('Backlogs', 0)) * 0.3
                        
                        merged_data.append({
                            'title': str(row.get('Title', ''))[:500],
                            'name': str(row.get('Name', ''))[:500],
                            'rating': float(row.get('Rating')) if pd.notna(row.get('Rating')) else None,
                            'platform': str(row.get('Platform', ''))[:50] if pd.notna(row.get('Platform')) else None,
                            'year': int(row.get('Year')) if pd.notna(row.get('Year')) else None,
                            'genre': str(row.get('Genre', ''))[:100] if pd.notna(row.get('Genre')) else None,
                            'publisher': str(row.get('Publisher', ''))[:200] if pd.notna(row.get('Publisher')) else None,
                            'global_sales': float(row.get('Global_Sales')) if pd.notna(row.get('Global_Sales')) else 0.0,
                            'plays': int(row.get('Plays')) if pd.notna(row.get('Plays')) else None,
                            'wishlist': int(row.get('Wishlist')) if pd.notna(row.get('Wishlist')) else None,
                            'backlogs': int(row.get('Backlogs')) if pd.notna(row.get('Backlogs')) else None,
                            'engagement_score': engagement_score
                        })
                    
                    if merged_data:
                        merged_df_clean = pd.DataFrame(merged_data)
                        merged_df_clean.to_sql('merged_analytics', conn, if_exists='append', index=False, method='multi')
                        self.logger.info(f"Inserted {len(merged_data)} merged analytics records")
                
                conn.commit()
                return True
                
        except SQLAlchemyError as e:
            self.logger.error(f"Error inserting data: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error inserting data: {e}")
            return False
    
    def execute_query(self, query: str, params: Optional[Dict] = None) -> Optional[pd.DataFrame]:
        """Execute a SQL query and return results as DataFrame"""
        if not self.connect():
            return None
        
        try:
            with self.engine.connect() as conn:
                if params:
                    result = conn.execute(text(query), params)
                else:
                    result = conn.execute(text(query))
                
                df = pd.DataFrame(result.fetchall(), columns=result.keys())
                return df
        except SQLAlchemyError as e:
            self.logger.error(f"Error executing query: {e}")
            return None
    
    def get_advanced_analytics(self) -> Dict[str, Any]:
        """Get comprehensive analytics from the database"""
        analytics = {}
        
        # Top performers analysis
        analytics['top_rated_games'] = self.execute_query("""
            SELECT title, rating, team, primary_genre, plays, wishlist
            FROM games_metadata 
            WHERE rating IS NOT NULL 
            ORDER BY rating DESC, number_of_reviews DESC 
            LIMIT 20
        """)
        
        # Sales performance by region
        analytics['regional_performance'] = self.execute_query("""
            SELECT 
                SUM(na_sales) as north_america,
                SUM(eu_sales) as europe,
                SUM(jp_sales) as japan,
                SUM(other_sales) as other_regions,
                SUM(global_sales) as global_total
            FROM sales_data
        """)
        
        # Platform analysis
        analytics['platform_analysis'] = self.execute_query("""
            SELECT 
                platform,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales,
                MAX(global_sales) as best_seller_sales
            FROM sales_data 
            WHERE platform IS NOT NULL
            GROUP BY platform
            ORDER BY total_sales DESC
            LIMIT 15
        """)
        
        # Genre performance
        analytics['genre_performance'] = self.execute_query("""
            SELECT 
                genre,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales
            FROM sales_data 
            WHERE genre IS NOT NULL
            GROUP BY genre
            ORDER BY total_sales DESC
        """)
        
        # Yearly trends
        analytics['yearly_trends'] = self.execute_query("""
            SELECT 
                year,
                COUNT(*) as releases,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales
            FROM sales_data 
            WHERE year IS NOT NULL AND year > 1980
            GROUP BY year
            ORDER BY year
        """)
        
        # Engagement correlation
        analytics['engagement_correlation'] = self.execute_query("""
            SELECT 
                rating,
                global_sales,
                plays,
                wishlist,
                backlogs,
                engagement_score
            FROM merged_analytics 
            WHERE rating IS NOT NULL AND global_sales IS NOT NULL
            ORDER BY engagement_score DESC
            LIMIT 1000
        """)
        
        # Publisher rankings
        analytics['publisher_rankings'] = self.execute_query("""
            SELECT 
                publisher,
                COUNT(*) as game_count,
                SUM(global_sales) as total_sales,
                AVG(global_sales) as avg_sales,
                MAX(global_sales) as best_seller_sales
            FROM sales_data 
            WHERE publisher IS NOT NULL
            GROUP BY publisher
            HAVING COUNT(*) >= 3
            ORDER BY total_sales DESC
            LIMIT 20
        """)
        
        return analytics
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get comprehensive database statistics"""
        stats = {}
        
        try:
            # Table counts
            stats['games_count'] = self.execute_query("SELECT COUNT(*) as count FROM games_metadata").iloc[0]['count']
            stats['sales_count'] = self.execute_query("SELECT COUNT(*) as count FROM sales_data").iloc[0]['count']
            stats['merged_count'] = self.execute_query("SELECT COUNT(*) as count FROM merged_analytics").iloc[0]['count']
            
            # Data quality metrics
            stats['games_with_ratings'] = self.execute_query("SELECT COUNT(*) as count FROM games_metadata WHERE rating IS NOT NULL").iloc[0]['count']
            stats['sales_with_data'] = self.execute_query("SELECT COUNT(*) as count FROM sales_data WHERE global_sales > 0").iloc[0]['count']
            
            # Date ranges
            year_range = self.execute_query("SELECT MIN(year) as min_year, MAX(year) as max_year FROM sales_data WHERE year IS NOT NULL")
            if not year_range.empty:
                stats['year_range'] = f"{year_range.iloc[0]['min_year']}-{year_range.iloc[0]['max_year']}"
            
            # Top metrics
            top_sales = self.execute_query("SELECT MAX(global_sales) as max_sales FROM sales_data")
            if not top_sales.empty:
                stats['highest_sales'] = top_sales.iloc[0]['max_sales']
            
            top_rating = self.execute_query("SELECT MAX(rating) as max_rating FROM games_metadata")
            if not top_rating.empty:
                stats['highest_rating'] = top_rating.iloc[0]['max_rating']
            
        except Exception as e:
            self.logger.error(f"Error getting database stats: {e}")
        
        return stats
    
    def create_views(self):
        """Create database views for common analytics queries"""
        if not self.connect():
            return False
        
        try:
            with self.engine.connect() as conn:
                # Top games view
                conn.execute(text("""
                    CREATE OR REPLACE VIEW top_games_view AS
                    SELECT 
                        g.title,
                        g.rating,
                        g.primary_genre,
                        s.global_sales,
                        s.platform,
                        s.year,
                        g.plays,
                        g.wishlist
                    FROM games_metadata g
                    JOIN sales_data s ON g.title_normalized = s.name_normalized
                    WHERE g.rating IS NOT NULL AND s.global_sales > 0
                    ORDER BY g.rating DESC, s.global_sales DESC
                """))
                
                # Regional preferences view
                conn.execute(text("""
                    CREATE OR REPLACE VIEW regional_preferences_view AS
                    SELECT 
                        genre,
                        SUM(na_sales) as na_total,
                        SUM(eu_sales) as eu_total,
                        SUM(jp_sales) as jp_total,
                        SUM(other_sales) as other_total,
                        SUM(global_sales) as global_total
                    FROM sales_data
                    WHERE genre IS NOT NULL
                    GROUP BY genre
                    ORDER BY global_total DESC
                """))
                
                conn.commit()
                self.logger.info("Successfully created database views")
                return True
                
        except SQLAlchemyError as e:
            self.logger.error(f"Error creating views: {e}")
            return False