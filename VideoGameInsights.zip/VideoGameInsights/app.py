import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import sqlite3
import numpy as np
from data_processor import DataProcessor
from database import DatabaseManager
from postgresql_manager import PostgreSQLManager
from visualizations import VisualizationManager

# Page configuration
st.set_page_config(
    page_title="Video Game Sales & Engagement Analysis",
    page_icon="🎮",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'processed_data' not in st.session_state:
    st.session_state.processed_data = {}

def main():
    st.title("🎮 Video Game Sales & Engagement Analysis")
    st.markdown("### Comprehensive Analytics Platform for Gaming Industry Insights")
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Select Analysis Section",
        [
            "Data Overview",
            "Game Metadata Analysis",
            "Sales Data Analysis", 
            "Merged Dataset Analysis",
            "Regional Analysis",
            "Genre & Platform Performance",
            "Developer & Publisher Insights",
            "Trend Analysis",
            "Advanced Database Analytics",
            "KPI Dashboard"
        ]
    )
    
    # Initialize components
    data_processor = DataProcessor()
    db_manager = PostgreSQLManager()  # Use PostgreSQL instead of SQLite
    viz_manager = VisualizationManager()
    
    # Data loading section
    st.sidebar.markdown("---")
    st.sidebar.subheader("Data Management")
    
    if st.sidebar.button("Load & Process Data"):
        with st.spinner("Loading and processing data..."):
            try:
                # Load CSV files
                games_df = pd.read_csv("attached_assets/games.csv")
                vgsales_df = pd.read_csv("attached_assets/vgsales.csv")
                
                # Process data
                games_clean = data_processor.clean_games_data(games_df)
                sales_clean = data_processor.clean_sales_data(vgsales_df)
                merged_df = data_processor.merge_datasets(games_clean, sales_clean)
                
                # Store in database
                db_manager.create_tables()
                db_manager.create_views()
                db_manager.insert_data(games_clean, sales_clean, merged_df)
                
                # Store in session state
                st.session_state.processed_data = {
                    'games': games_clean,
                    'sales': sales_clean,
                    'merged': merged_df
                }
                st.session_state.data_loaded = True
                st.sidebar.success("Data loaded successfully!")
                
            except Exception as e:
                st.sidebar.error(f"Error loading data: {str(e)}")
    
    # Display data status
    if st.session_state.data_loaded:
        st.sidebar.success("✅ Data Ready")
        games_df = st.session_state.processed_data['games']
        sales_df = st.session_state.processed_data['sales']
        merged_df = st.session_state.processed_data['merged']
        
        # Show database connection status
        db_stats = db_manager.get_database_stats()
        if db_stats:
            st.sidebar.info(f"📊 PostgreSQL: {db_stats.get('games_count', 0)} games, {db_stats.get('sales_count', 0)} sales records")
    else:
        st.warning("Please load the data first using the sidebar button.")
        return
    
    # Page routing
    if page == "Data Overview":
        show_data_overview(games_df, sales_df, merged_df)
    elif page == "Game Metadata Analysis":
        show_game_metadata_analysis(games_df, viz_manager)
    elif page == "Sales Data Analysis":
        show_sales_analysis(sales_df, viz_manager)
    elif page == "Merged Dataset Analysis":
        show_merged_analysis(merged_df, viz_manager)
    elif page == "Regional Analysis":
        show_regional_analysis(sales_df, merged_df, viz_manager)
    elif page == "Genre & Platform Performance":
        show_genre_platform_analysis(games_df, sales_df, merged_df, viz_manager)
    elif page == "Developer & Publisher Insights":
        show_developer_publisher_analysis(games_df, sales_df, viz_manager)
    elif page == "Trend Analysis":
        show_trend_analysis(games_df, sales_df, merged_df, viz_manager)
    elif page == "Advanced Database Analytics":
        show_database_analytics(db_manager, viz_manager)
    elif page == "KPI Dashboard":
        show_kpi_dashboard(games_df, sales_df, merged_df, viz_manager)

def show_data_overview(games_df, sales_df, merged_df):
    st.header("📊 Data Overview")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Games Dataset", f"{len(games_df):,} records")
        st.metric("Unique Genres", len(games_df['Genres'].dropna().unique()))
        st.metric("Avg Rating", f"{games_df['Rating'].mean():.2f}")
    
    with col2:
        st.metric("Sales Dataset", f"{len(sales_df):,} records")
        st.metric("Unique Platforms", len(sales_df['Platform'].unique()))
        st.metric("Total Global Sales", f"{sales_df['Global_Sales'].sum():.1f}M units")
    
    with col3:
        st.metric("Merged Dataset", f"{len(merged_df):,} records")
        st.metric("Match Rate", f"{len(merged_df)/max(len(games_df), len(sales_df))*100:.1f}%")
        st.metric("Year Range", f"{sales_df['Year'].min():.0f}-{sales_df['Year'].max():.0f}")
    
    # Data quality information
    st.subheader("Data Quality Summary")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Games Dataset Issues:**")
        games_issues = {
            'Missing Ratings': games_df['Rating'].isna().sum(),
            'Missing Release Dates': games_df['Release Date'].isna().sum(),
            'Missing Genres': games_df['Genres'].isna().sum(),
            'Missing Teams': games_df['Team'].isna().sum()
        }
        st.json(games_issues)
    
    with col2:
        st.write("**Sales Dataset Issues:**")
        sales_issues = {
            'Missing Years': sales_df['Year'].isna().sum(),
            'Missing Publishers': sales_df['Publisher'].isna().sum(),
            'Zero Global Sales': (sales_df['Global_Sales'] == 0).sum(),
            'Missing Genres': sales_df['Genre'].isna().sum()
        }
        st.json(sales_issues)

def show_game_metadata_analysis(games_df, viz_manager):
    st.header("🎮 Game Metadata Analysis")
    
    # Question 1: Top-rated games
    st.subheader("🌟 Top-Rated Games by User Reviews")
    top_rated = games_df.nlargest(10, 'Rating')[['Title', 'Rating', 'Team', 'Genres']]
    fig = px.bar(top_rated, x='Rating', y='Title', orientation='h',
                 title="Top 10 Highest-Rated Games",
                 labels={'Rating': 'User Rating', 'Title': 'Game Title'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 2: Developers with highest average ratings
    st.subheader("🧑‍🤝‍🧑 Developers with Highest Average Ratings")
    dev_ratings = viz_manager.analyze_developer_ratings(games_df)
    if not dev_ratings.empty:
        fig = px.bar(dev_ratings.head(10), x='avg_rating', y='Team', orientation='h',
                     title="Top 10 Developers by Average Rating")
        st.plotly_chart(fig, use_container_width=True)
    
    # Question 3: Most common genres
    st.subheader("🧩 Most Common Genres")
    genre_counts = viz_manager.analyze_genre_distribution(games_df)
    if not genre_counts.empty:
        fig = px.pie(genre_counts.head(10), values='count', names='genre',
                     title="Genre Distribution (Top 10)")
        st.plotly_chart(fig, use_container_width=True)
    
    # Question 4: Backlog vs Wishlist
    st.subheader("⏳ Games with Highest Backlog vs Wishlist Ratio")
    backlog_analysis = games_df.copy()
    backlog_analysis = backlog_analysis.dropna(subset=['Backlogs', 'Wishlist'])
    backlog_analysis = backlog_analysis[(backlog_analysis['Backlogs'] > 0) & (backlog_analysis['Wishlist'] > 0)]
    backlog_analysis['Backlog_Wishlist_Ratio'] = backlog_analysis['Backlogs'] / backlog_analysis['Wishlist']
    top_backlog = backlog_analysis.nlargest(15, 'Backlog_Wishlist_Ratio')[['Title', 'Backlogs', 'Wishlist', 'Backlog_Wishlist_Ratio']]
    
    fig = px.scatter(top_backlog, x='Wishlist', y='Backlogs', size='Backlog_Wishlist_Ratio',
                     hover_data=['Title'], title="Backlog vs Wishlist Analysis")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 5: Release trend over years
    st.subheader("🗓️ Game Release Trend Across Years")
    release_trend = viz_manager.analyze_release_trends(games_df)
    if not release_trend.empty:
        fig = px.line(release_trend, x='year', y='count',
                      title="Game Releases Over Time")
        st.plotly_chart(fig, use_container_width=True)
    
    # Question 6: Rating distribution
    st.subheader("🔎 Distribution of User Ratings")
    fig = px.histogram(games_df.dropna(subset=['Rating']), x='Rating', nbins=20,
                       title="Distribution of Game Ratings")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 7: Top wishlisted games
    st.subheader("🧑 Top 10 Most Wishlisted Games")
    top_wishlist = games_df.nlargest(10, 'Wishlist')[['Title', 'Wishlist', 'Rating', 'Genres']]
    fig = px.bar(top_wishlist, x='Wishlist', y='Title', orientation='h',
                 title="Most Wishlisted Games")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 8: Average plays per genre
    st.subheader("🔬 Average Number of Plays per Genre")
    genre_plays = viz_manager.analyze_plays_by_genre(games_df)
    if not genre_plays.empty:
        fig = px.bar(genre_plays, x='avg_plays', y='genre', orientation='h',
                     title="Average Plays by Genre")
        st.plotly_chart(fig, use_container_width=True)

def show_sales_analysis(sales_df, viz_manager):
    st.header("💰 Sales Data Analysis")
    
    # Question 10: Regional sales comparison
    st.subheader("🌍 Regional Sales Comparison")
    regional_sales = {
        'North America': sales_df['NA_Sales'].sum(),
        'Europe': sales_df['EU_Sales'].sum(),
        'Japan': sales_df['JP_Sales'].sum(),
        'Other': sales_df['Other_Sales'].sum()
    }
    
    fig = px.pie(values=list(regional_sales.values()), names=list(regional_sales.keys()),
                 title="Global Sales by Region (Million Units)")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 11: Best-selling platforms
    st.subheader("🕹️ Best-Selling Platforms")
    platform_sales = sales_df.groupby('Platform')['Global_Sales'].sum().sort_values(ascending=False).head(15)
    fig = px.bar(x=platform_sales.values, y=platform_sales.index, orientation='h',
                 title="Top 15 Platforms by Global Sales",
                 labels={'x': 'Global Sales (Million Units)', 'y': 'Platform'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 12: Sales trends over years
    st.subheader("📅 Sales Trends Over Years")
    yearly_sales = sales_df.groupby('Year')['Global_Sales'].sum().reset_index()
    yearly_releases = sales_df.groupby('Year').size().reset_index(name='releases')
    
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(x=yearly_sales['Year'], y=yearly_sales['Global_Sales'],
                            mode='lines+markers', name='Total Sales'))
    fig.add_trace(go.Scatter(x=yearly_releases['Year'], y=yearly_releases['releases'],
                            mode='lines+markers', name='Number of Releases'), secondary_y=True)
    
    fig.update_xaxes(title_text="Year")
    fig.update_yaxes(title_text="Global Sales (Million Units)", secondary_y=False)
    fig.update_yaxes(title_text="Number of Releases", secondary_y=True)
    fig.update_layout(title="Game Sales and Release Trends Over Time")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 13: Top publishers by sales
    st.subheader("🏢 Top Publishers by Sales")
    publisher_sales = sales_df.groupby('Publisher')['Global_Sales'].sum().sort_values(ascending=False).head(15)
    fig = px.bar(x=publisher_sales.values, y=publisher_sales.index, orientation='h',
                 title="Top 15 Publishers by Global Sales",
                 labels={'x': 'Global Sales (Million Units)', 'y': 'Publisher'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 14: Top 10 best-sellers globally
    st.subheader("🔝 Top 10 Best-Selling Games Globally")
    top_games = sales_df.nlargest(10, 'Global_Sales')[['Name', 'Platform', 'Global_Sales', 'Genre', 'Publisher']]
    fig = px.bar(top_games, x='Global_Sales', y='Name', orientation='h',
                 color='Platform', title="Top 10 Best-Selling Games")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 15: Regional sales by platform
    st.subheader("🧭 Regional Sales Comparison by Platform")
    platform_choice = st.selectbox("Select Platform:", sales_df['Platform'].unique())
    
    platform_data = sales_df[sales_df['Platform'] == platform_choice]
    regional_platform = {
        'North America': platform_data['NA_Sales'].sum(),
        'Europe': platform_data['EU_Sales'].sum(),  
        'Japan': platform_data['JP_Sales'].sum(),
        'Other': platform_data['Other_Sales'].sum()
    }
    
    fig = px.bar(x=list(regional_platform.keys()), y=list(regional_platform.values()),
                 title=f"Regional Sales for {platform_choice}",
                 labels={'x': 'Region', 'y': 'Sales (Million Units)'})
    st.plotly_chart(fig, use_container_width=True)

def show_merged_analysis(merged_df, viz_manager):
    st.header("🔁 Merged Dataset Analysis")
    
    if merged_df.empty:
        st.warning("No merged data available. Please ensure data is properly loaded.")
        return
    
    # Question 21: Genre sales analysis
    st.subheader("🎮 Game Genres vs Global Sales")
    genre_sales = merged_df.groupby('Genre')['Global_Sales'].sum().sort_values(ascending=False).head(10)
    fig = px.bar(x=genre_sales.values, y=genre_sales.index, orientation='h',
                 title="Top 10 Genres by Global Sales")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 22: Rating vs Sales correlation
    st.subheader("🎯 User Rating vs Global Sales Correlation")
    correlation_data = merged_df.dropna(subset=['Rating', 'Global_Sales'])
    if not correlation_data.empty:
        fig = px.scatter(correlation_data, x='Rating', y='Global_Sales',
                        title="Rating vs Global Sales Correlation",
                        trendline="ols")
        st.plotly_chart(fig, use_container_width=True)
        
        # Show correlation coefficient
        corr_coef = correlation_data['Rating'].corr(correlation_data['Global_Sales'])
        st.metric("Correlation Coefficient", f"{corr_coef:.3f}")
    
    # Question 23: High-rated games by platform
    st.subheader("🕹️ Platforms with Most High-Rated Games (>4.0)")
    high_rated = merged_df[merged_df['Rating'] > 4.0]
    platform_high_rated = high_rated.groupby('Platform').size().sort_values(ascending=False).head(10)
    fig = px.bar(x=platform_high_rated.values, y=platform_high_rated.index, orientation='h',
                 title="Platforms with Most High-Rated Games")
    st.plotly_chart(fig, use_container_width=True)
    
    # Question 25: Wishlist vs Sales correlation
    st.subheader("🧍 Wishlist vs Sales Correlation")
    wishlist_sales = merged_df.dropna(subset=['Wishlist', 'Global_Sales'])
    if not wishlist_sales.empty:
        fig = px.scatter(wishlist_sales, x='Wishlist', y='Global_Sales',
                        title="Wishlist Count vs Global Sales",
                        trendline="ols")
        st.plotly_chart(fig, use_container_width=True)

def show_regional_analysis(sales_df, merged_df, viz_manager):
    st.header("🌐 Regional Analysis")
    
    # Regional preferences by genre
    st.subheader("📍 Regional Genre Preferences")
    
    # Create regional preference analysis
    regional_genre = sales_df.groupby('Genre')[['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']].sum()
    regional_genre_pct = regional_genre.div(regional_genre.sum(axis=1), axis=0)
    
    fig = px.imshow(regional_genre_pct.T, 
                    labels=dict(x="Genre", y="Region", color="Percentage"),
                    title="Regional Genre Preferences Heatmap")
    st.plotly_chart(fig, use_container_width=True)
    
    # Year-over-year regional changes
    st.subheader("🔄 Yearly Sales Change by Region")
    yearly_regional = sales_df.groupby('Year')[['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']].sum()
    
    fig = px.line(yearly_regional.reset_index(), x='Year', 
                  y=['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales'],
                  title="Regional Sales Trends Over Time")
    st.plotly_chart(fig, use_container_width=True)

def show_genre_platform_analysis(games_df, sales_df, merged_df, viz_manager):
    st.header("🎯 Genre & Platform Performance")
    
    # Top genre-platform combinations
    st.subheader("🎉 Top-Performing Genre + Platform Combinations")
    if not merged_df.empty:
        combo_performance = merged_df.groupby(['Genre', 'Platform'])['Global_Sales'].sum().sort_values(ascending=False).head(15)
        combo_df = combo_performance.reset_index()
        combo_df['Combination'] = combo_df['Genre'] + ' + ' + combo_df['Platform']
        
        fig = px.bar(combo_df, x='Global_Sales', y='Combination', orientation='h',
                     title="Top 15 Genre-Platform Combinations by Sales")
        st.plotly_chart(fig, use_container_width=True)
    
    # Genre engagement vs sales
    st.subheader("🎮 Genres with High Engagement but Low Sales")
    if not merged_df.empty:
        genre_analysis = merged_df.groupby('Genre').agg({
            'Plays': 'mean',
            'Wishlist': 'mean', 
            'Global_Sales': 'mean'
        }).reset_index()
        
        fig = px.scatter(genre_analysis, x='Global_Sales', y='Plays',
                        size='Wishlist', hover_data=['Genre'],
                        title="Genre Performance: Engagement vs Sales")
        st.plotly_chart(fig, use_container_width=True)

def show_developer_publisher_analysis(games_df, sales_df, viz_manager):
    st.header("🏢 Developer & Publisher Insights")
    
    # Most productive developers
    st.subheader("🧑 Most Productive Developer Studios")
    dev_productivity = viz_manager.analyze_developer_productivity(games_df)
    if not dev_productivity.empty:
        fig = px.bar(dev_productivity.head(15), x='game_count', y='Team', orientation='h',
                     title="Top 15 Most Productive Developers (by Game Count)")
        st.plotly_chart(fig, use_container_width=True)
    
    # Publisher performance
    st.subheader("📊 Average Sales per Publisher")
    publisher_avg = sales_df.groupby('Publisher')['Global_Sales'].agg(['mean', 'count']).reset_index()
    publisher_avg = publisher_avg[publisher_avg['count'] >= 5]  # At least 5 games
    publisher_avg = publisher_avg.sort_values('mean', ascending=False).head(15)
    
    fig = px.bar(publisher_avg, x='mean', y='Publisher', orientation='h',
                 title="Top 15 Publishers by Average Sales per Game (Min 5 games)")
    st.plotly_chart(fig, use_container_width=True)

def show_trend_analysis(games_df, sales_df, merged_df, viz_manager):
    st.header("📈 Trend Analysis")
    
    # Platform evolution over time
    st.subheader("📈 Platform Market Evolution")
    platform_yearly = sales_df.groupby(['Year', 'Platform'])['Global_Sales'].sum().reset_index()
    
    # Get top platforms for visualization
    top_platforms = sales_df.groupby('Platform')['Global_Sales'].sum().nlargest(8).index
    platform_yearly_filtered = platform_yearly[platform_yearly['Platform'].isin(top_platforms)]
    
    fig = px.line(platform_yearly_filtered, x='Year', y='Global_Sales', color='Platform',
                  title="Platform Performance Over Time (Top 8 Platforms)")
    st.plotly_chart(fig, use_container_width=True)
    
    # Release and sales correlation over time
    st.subheader("📅 Release Patterns vs Sales Performance")
    if not merged_df.empty:
        yearly_performance = merged_df.groupby('Year').agg({
            'Global_Sales': ['sum', 'mean'],
            'Rating': 'mean'
        }).reset_index()
        yearly_performance.columns = ['Year', 'Total_Sales', 'Avg_Sales', 'Avg_Rating']
        
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig.add_trace(go.Scatter(x=yearly_performance['Year'], y=yearly_performance['Total_Sales'],
                                mode='lines+markers', name='Total Sales'))
        fig.add_trace(go.Scatter(x=yearly_performance['Year'], y=yearly_performance['Avg_Rating'],
                                mode='lines+markers', name='Average Rating'), secondary_y=True)
        
        fig.update_xaxes(title_text="Year")
        fig.update_yaxes(title_text="Total Sales (Million Units)", secondary_y=False)
        fig.update_yaxes(title_text="Average Rating", secondary_y=True)
        fig.update_layout(title="Sales vs Quality Trends Over Time")
        st.plotly_chart(fig, use_container_width=True)

def show_kpi_dashboard(games_df, sales_df, merged_df, viz_manager):
    st.header("📊 KPI Dashboard")
    
    # Key Performance Indicators
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_sales = sales_df['Global_Sales'].sum()
        st.metric("Total Global Sales", f"{total_sales:.1f}M units")
        
        avg_rating = games_df['Rating'].mean()
        st.metric("Average Game Rating", f"{avg_rating:.2f}")
    
    with col2:
        total_games = len(sales_df['Name'].unique())
        st.metric("Total Unique Games", f"{total_games:,}")
        
        total_wishlist = games_df['Wishlist'].sum()
        st.metric("Total Wishlist Count", f"{total_wishlist:,.0f}")
    
    with col3:
        total_platforms = len(sales_df['Platform'].unique())
        st.metric("Total Platforms", total_platforms)
        
        total_plays = games_df['Plays'].sum()
        st.metric("Total Plays", f"{total_plays:,.0f}")
    
    with col4:
        top_genre = sales_df.groupby('Genre')['Global_Sales'].sum().idxmax()
        st.metric("Top Genre by Sales", top_genre)
        
        years_span = int(sales_df['Year'].max() - sales_df['Year'].min())
        st.metric("Analysis Period", f"{years_span} years")
    
    # Market share analysis
    st.subheader("Market Share Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Top 5 platforms market share
        platform_share = sales_df.groupby('Platform')['Global_Sales'].sum().nlargest(5)
        fig = px.pie(values=platform_share.values, names=platform_share.index,
                     title="Top 5 Platforms Market Share")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Top 5 publishers market share
        publisher_share = sales_df.groupby('Publisher')['Global_Sales'].sum().nlargest(5)
        fig = px.pie(values=publisher_share.values, names=publisher_share.index,
                     title="Top 5 Publishers Market Share")
        st.plotly_chart(fig, use_container_width=True)
    
    # Performance summary table
    st.subheader("Performance Summary")
    
    if not merged_df.empty:
        summary_stats = {
            'Metric': [
                'Games with Rating > 4.0',
                'Games with >1M Sales',
                'Most Popular Genre',
                'Best Performing Platform',
                'Average Wishlist per Game',
                'Correlation: Rating vs Sales'
            ],
            'Value': [
                len(merged_df[merged_df['Rating'] > 4.0]),
                len(merged_df[merged_df['Global_Sales'] > 1.0]),
                merged_df.groupby('Genre')['Global_Sales'].sum().idxmax(),
                merged_df.groupby('Platform')['Global_Sales'].sum().idxmax(),
                f"{merged_df['Wishlist'].mean():.0f}",
                f"{merged_df['Rating'].corr(merged_df['Global_Sales']):.3f}"
            ]
        }
        
        summary_df = pd.DataFrame(summary_stats)
        st.table(summary_df)

def show_database_analytics(db_manager, viz_manager):
    st.header("🗄️ Advanced Database Analytics")
    st.markdown("### PostgreSQL-Powered Analytics and Insights")
    
    # Get comprehensive analytics from database
    with st.spinner("Loading advanced analytics from PostgreSQL database..."):
        analytics = db_manager.get_advanced_analytics()
        db_stats = db_manager.get_database_stats()
    
    # Database Statistics Overview
    st.subheader("📊 Database Statistics")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Games", f"{db_stats.get('games_count', 0):,}")
        st.metric("Games with Ratings", f"{db_stats.get('games_with_ratings', 0):,}")
    
    with col2:
        st.metric("Total Sales Records", f"{db_stats.get('sales_count', 0):,}")
        st.metric("Active Sales Data", f"{db_stats.get('sales_with_data', 0):,}")
    
    with col3:
        st.metric("Merged Analytics", f"{db_stats.get('merged_count', 0):,}")
        st.metric("Year Range", db_stats.get('year_range', 'N/A'))
    
    with col4:
        st.metric("Highest Sales", f"{db_stats.get('highest_sales', 0):.1f}M" if db_stats.get('highest_sales') else "N/A")
        st.metric("Top Rating", f"{db_stats.get('highest_rating', 0):.1f}" if db_stats.get('highest_rating') else "N/A")
    
    # Advanced Analytics Visualizations
    if analytics:
        # Top Rated Games from Database
        if analytics.get('top_rated_games') is not None and not analytics['top_rated_games'].empty:
            st.subheader("🌟 Top Rated Games (Database Query)")
            top_games = analytics['top_rated_games'].head(10)
            fig = px.bar(top_games, x='rating', y='title', orientation='h',
                        title="Top 10 Highest Rated Games from PostgreSQL",
                        hover_data=['team', 'primary_genre'])
            st.plotly_chart(fig, use_container_width=True)
        
        # Platform Performance Analysis
        if analytics.get('platform_analysis') is not None and not analytics['platform_analysis'].empty:
            st.subheader("🕹️ Platform Performance Analysis")
            platform_data = analytics['platform_analysis']
            
            col1, col2 = st.columns(2)
            with col1:
                fig = px.bar(platform_data.head(10), x='total_sales', y='platform', 
                           orientation='h', title="Top Platforms by Total Sales")
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                fig = px.scatter(platform_data, x='game_count', y='avg_sales', size='total_sales',
                               hover_data=['platform'], title="Platform Efficiency Analysis")
                st.plotly_chart(fig, use_container_width=True)
        
        # Genre Performance
        if analytics.get('genre_performance') is not None and not analytics['genre_performance'].empty:
            st.subheader("🎮 Genre Performance Insights")
            genre_data = analytics['genre_performance']
            
            fig = px.treemap(genre_data.head(15), path=['genre'], values='total_sales',
                           title="Genre Market Share (Treemap)")
            st.plotly_chart(fig, use_container_width=True)
        
        # Publisher Rankings
        if analytics.get('publisher_rankings') is not None and not analytics['publisher_rankings'].empty:
            st.subheader("🏢 Publisher Performance Rankings")
            publisher_data = analytics['publisher_rankings'].head(15)
            
            fig = px.bar(publisher_data, x='total_sales', y='publisher', orientation='h',
                        color='avg_sales', title="Top Publishers by Total Sales")
            st.plotly_chart(fig, use_container_width=True)
    
    # Custom SQL Query Section
    st.subheader("🔍 Custom Database Query")
    st.markdown("Execute custom SQL queries on the PostgreSQL database:")
    
    query_examples = {
        "Top 5 Games by Region": """
            SELECT name, platform, na_sales, eu_sales, jp_sales, global_sales 
            FROM sales_data 
            ORDER BY global_sales DESC 
            LIMIT 5
        """,
        "Average Rating by Genre": """
            SELECT primary_genre, AVG(rating) as avg_rating, COUNT(*) as game_count 
            FROM games_metadata 
            WHERE rating IS NOT NULL AND primary_genre IS NOT NULL 
            GROUP BY primary_genre 
            ORDER BY avg_rating DESC
        """,
        "Sales Trends by Year": """
            SELECT year, COUNT(*) as releases, SUM(global_sales) as total_sales 
            FROM sales_data 
            WHERE year BETWEEN 2000 AND 2020 
            GROUP BY year 
            ORDER BY year
        """
    }
    
    selected_example = st.selectbox("Choose a query example:", list(query_examples.keys()))
    
    custom_query = st.text_area(
        "SQL Query:", 
        value=query_examples[selected_example],
        height=150
    )
    
    if st.button("Execute Query"):
        if custom_query.strip():
            try:
                with st.spinner("Executing query..."):
                    result = db_manager.execute_query(custom_query)
                
                if result is not None and not result.empty:
                    st.success(f"Query executed successfully! Retrieved {len(result)} rows.")
                    st.dataframe(result, use_container_width=True)
                    
                    # Auto-generate simple visualization if possible
                    if len(result.columns) >= 2:
                        numeric_columns = result.select_dtypes(include=['number']).columns
                        if len(numeric_columns) >= 1:
                            st.subheader("Quick Visualization")
                            x_col = result.columns[0]
                            y_col = numeric_columns[0]
                            
                            if len(result) <= 50:  # Only for reasonable dataset sizes
                                fig = px.bar(result.head(20), x=x_col, y=y_col, 
                                           title=f"{y_col} by {x_col}")
                                st.plotly_chart(fig, use_container_width=True)
                else:
                    st.warning("Query executed but returned no results.")
                    
            except Exception as e:
                st.error(f"Query execution error: {str(e)}")
        else:
            st.warning("Please enter a SQL query.")

if __name__ == "__main__":
    main()
