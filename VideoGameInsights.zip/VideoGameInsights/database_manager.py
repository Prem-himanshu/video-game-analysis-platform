import sqlite3
import pandas as pd
import os

class DatabaseManager:
    """
    Database manager for storing and retrieving video game data
    """
    
    def __init__(self, db_path="video_games.db"):
        self.db_path = db_path
        self.connection = None
    
    def connect(self):
        """Create database connection"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            return self.connection
        except sqlite3.Error as e:
            raise Exception(f"Database connection error: {str(e)}")
    
    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
    
    def create_tables(self):
        """Create database tables for video game data"""
        conn = self.connect()
        cursor = conn.cursor()
        
        try:
            # Games table (engagement data)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS games (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    release_date TEXT,
                    release_year INTEGER,
                    team TEXT,
                    rating REAL,
                    times_listed INTEGER,
                    number_of_reviews INTEGER,
                    genres TEXT,
                    summary TEXT,
                    reviews TEXT,
                    plays INTEGER,
                    playing INTEGER,
                    backlogs INTEGER,
                    wishlist INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Sales table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rank_position INTEGER,
                    name TEXT NOT NULL,
                    platform TEXT,
                    year INTEGER,
                    genre TEXT,
                    publisher TEXT,
                    na_sales REAL,
                    eu_sales REAL,
                    jp_sales REAL,
                    other_sales REAL,
                    global_sales REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Merged data table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS merged_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    name TEXT,
                    rating REAL,
                    genres TEXT,
                    platform TEXT,
                    year INTEGER,
                    publisher TEXT,
                    global_sales REAL,
                    na_sales REAL,
                    eu_sales REAL,
                    jp_sales REAL,
                    other_sales REAL,
                    plays INTEGER,
                    wishlist INTEGER,
                    backlogs INTEGER,
                    team TEXT,
                    sales_per_rating REAL,
                    wishlist_to_sales_ratio REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_games_title ON games(title)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_name ON sales(name)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_platform ON sales(platform)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_year ON sales(year)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_merged_title ON merged_data(title)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_merged_platform ON merged_data(platform)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_merged_rating ON merged_data(rating)')
            
            conn.commit()
            
        except sqlite3.Error as e:
            conn.rollback()
            raise Exception(f"Error creating tables: {str(e)}")
        finally:
            conn.close()
    
    def insert_data(self, games_df, sales_df, merged_df):
        """Insert cleaned data into database tables"""
        conn = self.connect()
        
        try:
            # Clear existing data
            cursor = conn.cursor()
            cursor.execute('DELETE FROM games')
            cursor.execute('DELETE FROM sales')
            cursor.execute('DELETE FROM merged_data')
            
            # Insert games data
            games_columns = [
                'title', 'release_date', 'release_year', 'team', 'rating',
                'times_listed', 'number_of_reviews', 'genres', 'summary',
                'reviews', 'plays', 'playing', 'backlogs', 'wishlist'
            ]
            
            games_data = []
            for _, row in games_df.iterrows():
                games_data.append([
                    row.get('Title', ''),
                    str(row.get('Release Date', '')) if pd.notna(row.get('Release Date')) else None,
                    int(row.get('Release_Year', 0)) if pd.notna(row.get('Release_Year')) else None,
                    str(row.get('Team', '')),
                    float(row.get('Rating', 0)) if pd.notna(row.get('Rating')) else None,
                    int(row.get('Times Listed', 0)) if pd.notna(row.get('Times Listed')) else 0,
                    int(row.get('Number of Reviews', 0)) if pd.notna(row.get('Number of Reviews')) else 0,
                    str(row.get('Genres', '')),
                    str(row.get('Summary', '')),
                    str(row.get('Reviews', '')),
                    int(row.get('Plays', 0)) if pd.notna(row.get('Plays')) else 0,
                    int(row.get('Playing', 0)) if pd.notna(row.get('Playing')) else 0,
                    int(row.get('Backlogs', 0)) if pd.notna(row.get('Backlogs')) else 0,
                    int(row.get('Wishlist', 0)) if pd.notna(row.get('Wishlist')) else 0
                ])
            
            cursor.executemany(f'''
                INSERT INTO games ({', '.join(games_columns)})
                VALUES ({', '.join(['?' for _ in games_columns])})
            ''', games_data)
            
            # Insert sales data
            sales_columns = [
                'rank_position', 'name', 'platform', 'year', 'genre', 'publisher',
                'na_sales', 'eu_sales', 'jp_sales', 'other_sales', 'global_sales'
            ]
            
            sales_data = []
            for _, row in sales_df.iterrows():
                sales_data.append([
                    int(row.get('Rank', 0)) if pd.notna(row.get('Rank')) else None,
                    str(row.get('Name', '')),
                    str(row.get('Platform', '')),
                    int(row.get('Year', 0)) if pd.notna(row.get('Year')) else None,
                    str(row.get('Genre', '')),
                    str(row.get('Publisher', '')),
                    float(row.get('NA_Sales', 0)) if pd.notna(row.get('NA_Sales')) else 0,
                    float(row.get('EU_Sales', 0)) if pd.notna(row.get('EU_Sales')) else 0,
                    float(row.get('JP_Sales', 0)) if pd.notna(row.get('JP_Sales')) else 0,
                    float(row.get('Other_Sales', 0)) if pd.notna(row.get('Other_Sales')) else 0,
                    float(row.get('Global_Sales', 0)) if pd.notna(row.get('Global_Sales')) else 0
                ])
            
            cursor.executemany(f'''
                INSERT INTO sales ({', '.join(sales_columns)})
                VALUES ({', '.join(['?' for _ in sales_columns])})
            ''', sales_data)
            
            # Insert merged data
            merged_columns = [
                'title', 'name', 'rating', 'genres', 'platform', 'year', 'publisher',
                'global_sales', 'na_sales', 'eu_sales', 'jp_sales', 'other_sales',
                'plays', 'wishlist', 'backlogs', 'team', 'sales_per_rating', 'wishlist_to_sales_ratio'
            ]
            
            merged_data = []
            for _, row in merged_df.iterrows():
                merged_data.append([
                    str(row.get('Title', '')),
                    str(row.get('Name', '')),
                    float(row.get('Rating', 0)) if pd.notna(row.get('Rating')) else None,
                    str(row.get('Genres', '')),
                    str(row.get('Platform', '')),
                    int(row.get('Release_Year', 0)) if pd.notna(row.get('Release_Year')) else None,
                    str(row.get('Publisher', '')),
                    float(row.get('Global_Sales', 0)) if pd.notna(row.get('Global_Sales')) else 0,
                    float(row.get('NA_Sales', 0)) if pd.notna(row.get('NA_Sales')) else 0,
                    float(row.get('EU_Sales', 0)) if pd.notna(row.get('EU_Sales')) else 0,
                    float(row.get('JP_Sales', 0)) if pd.notna(row.get('JP_Sales')) else 0,
                    float(row.get('Other_Sales', 0)) if pd.notna(row.get('Other_Sales')) else 0,
                    int(row.get('Plays', 0)) if pd.notna(row.get('Plays')) else 0,
                    int(row.get('Wishlist', 0)) if pd.notna(row.get('Wishlist')) else 0,
                    int(row.get('Backlogs', 0)) if pd.notna(row.get('Backlogs')) else 0,
                    str(row.get('Team', '')),
                    float(row.get('Sales_per_Rating', 0)) if pd.notna(row.get('Sales_per_Rating')) else None,
                    float(row.get('Wishlist_to_Sales_Ratio', 0)) if pd.notna(row.get('Wishlist_to_Sales_Ratio')) else None
                ])
            
            cursor.executemany(f'''
                INSERT INTO merged_data ({', '.join(merged_columns)})
                VALUES ({', '.join(['?' for _ in merged_columns])})
            ''', merged_data)
            
            conn.commit()
            
        except sqlite3.Error as e:
            conn.rollback()
            raise Exception(f"Error inserting data: {str(e)}")
        finally:
            conn.close()
    
    def execute_query(self, query, params=None):
        """Execute a SQL query and return results"""
        conn = self.connect()
        
        try:
            if params:
                df = pd.read_sql_query(query, conn, params=params)
            else:
                df = pd.read_sql_query(query, conn)
            return df
        except sqlite3.Error as e:
            raise Exception(f"Query execution error: {str(e)}")
        finally:
            conn.close()
    
    def get_table_info(self, table_name):
        """Get information about a table"""
        conn = self.connect()
        cursor = conn.cursor()
        
        try:
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = cursor.fetchone()[0]
            
            return {
                'columns': columns,
                'row_count': row_count
            }
        except sqlite3.Error as e:
            raise Exception(f"Error getting table info: {str(e)}")
        finally:
            conn.close()
    
    def backup_database(self, backup_path):
        """Create a backup of the database"""
        try:
            conn = self.connect()
            backup_conn = sqlite3.connect(backup_path)
            conn.backup(backup_conn)
            backup_conn.close()
            conn.close()
            return True
        except sqlite3.Error as e:
            raise Exception(f"Backup error: {str(e)}")
